 
(function () {

	// ################### UI ################### 

    // STEP 1: Grab all <b> tags from the target container
    const container = document.querySelector("#rightPane > div:nth-child(4) > div");
    if (!container) return console.warn("Target container not found");

    const bTags = Array.from(container.querySelectorAll("b"));

    // STEP 2: Inject CSS via <style> tag
    const style = document.createElement("style");
    style.textContent = `
        #bTagSearchBox {
            position: fixed;
            top: 10px;
            right: 10px;
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 10px;
            z-index: 9999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            font-family: sans-serif;
        }

        #bTagSearchBox input {
            width: 100%;
            margin-bottom: 8px;
            padding: 6px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        #bTagSearchBox ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        #bTagSearchBox li {
            padding: 4px 6px;
            cursor: pointer;
            border-bottom: 1px solid #eee;
        }

        #bTagSearchBox li:hover {
            background-color: #f0f0f0;
        }

        .highlighted-btag {
            background-color: yellow !important;
            transition: background-color 0.3s ease;
        }
    `;
    document.head.appendChild(style);

    // STEP 3: Create UI container
    const uiContainer = document.createElement("div");
    uiContainer.id = "bTagSearchBox";

    // Search input
    const searchInput = document.createElement("input");
    searchInput.type = "text";
    searchInput.placeholder = "Search symbols...";

    // Result list
    const resultList = document.createElement("ul");

    // Function to filter and render
    function renderList(query) {
        const lowerQuery = query.toLowerCase();
        resultList.innerHTML = "";

        const filtered = bTags.filter(el => el.title?.toLowerCase().includes(lowerQuery));

  		filtered.forEach(el => {
    		const item = document.createElement("li");
		
    		// Process title: remove first char, then extract until first \n\n
    		let processedTitle = el.title.substring(1); // remove first character
    		const endIndex = processedTitle.indexOf("\n\n");
    		if (endIndex !== -1) {
        		processedTitle = processedTitle.substring(0, endIndex);
    		}
		
			// Set the inner HTML: el.innerHTML and processedTitle on same line
			item.innerHTML = `
    			<div>
        			${el.innerHTML}&nbsp;
        			<span style="color: grey; font-size: 0.8em;">${processedTitle}</span>
    			</div>
			`;
			
			// Attach custom property 'moi' to item
			item.moi = el.innerHTML;
			
			item.addEventListener("click", (event) => {
    			el.scrollIntoView({ behavior: "smooth", block: "center" });
			
    			// Highlight effect
    			el.classList.add("highlighted-btag");
    			setTimeout(() => el.classList.remove("highlighted-btag"), 1500);
			
    			const inputEl = document.querySelector("#oneLineInput");
			
    			// Get the clicked item from event.currentTarget
    			const clickedItem = event.currentTarget;
			
    			console.log(clickedItem.moi); // should log el.innerHTML
			
    			inputEl.value += clickedItem.moi;

			});
			
			resultList.appendChild(item);
			
		});
		
		

        if (filtered.length === 0 && query) {
            const noMatch = document.createElement("li");
            noMatch.textContent = "No matches found";
            noMatch.style.color = "#888";
            resultList.appendChild(noMatch);
        }
    }

    // Input event listener
    searchInput.addEventListener("input", (e) => {
        renderList(e.target.value);
    });

    // Assemble and insert UI
    uiContainer.appendChild(searchInput);
    uiContainer.appendChild(resultList);
    document.body.appendChild(uiContainer);

    // Initial render
    renderList("");
    
    // ################ TOGGLE VISIBILITY ###############
    
    // Find the reference element (the button with id 'oneLineSubmit')
	const submitBtn = document.querySelector("#oneLineSubmit");
	
	// Create the toggle button
	const toggleBtn = document.createElement("button");
	//toggleBtn.textContent = "Toggle UI Container";
	toggleBtn.innerHTML = '<svg class="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-width="2" d="m21 21-3.5-3.5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"/></svg>'
	toggleBtn.classList.add('run')
	
	// Insert the toggle button before the submit button
	submitBtn.parentNode.insertBefore(toggleBtn, submitBtn);
		
	// Add click event to toggle visibility
	toggleBtn.addEventListener("click", () => {
  	if (uiContainer.style.display === "none") {
    	uiContainer.style.display = "block";
  	} else {
    	uiContainer.style.display = "none";
  	}
	});
	
})();
